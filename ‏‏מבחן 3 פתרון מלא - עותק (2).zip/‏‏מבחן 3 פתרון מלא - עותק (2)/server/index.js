const express = require("express");
const app = express();
const { pool } = require("../pool/dbconnection");

const cors = require("cors");



//cors- so that react could get the info from server side to client side=react

app.use(
  cors({
    mode: "no-cors",
    origin: "http://localhost:3000",
  })
);



//return all from comapnies table
app.route("/companies").get((req, res) => {
  pool.query("SELECT * FROM test_3.companies", (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});


//return all from servers table
app.route("/servers").get((req, res) => {
    pool.query("SELECT * FROM test_3.servers", (err, results) => {
      if (err) throw err;
      res.json(results);
    });
  });

//return by server-name with the id of 1 from servers table

app.route("/server/name").get((req, res) => {
  pool.query(
    "SELECT * FROM test_3.servers WHERE id= '1'",
    (err, results) => {
      if (err) throw err;
      res.json(results);
    }
  );
});



//return by server-name with the id of 1 from companies table

app.route("/company/name").get((req, res) => {
    pool.query(
      "SELECT * FROM test_3.companies WHERE id= '1'",
      (err, results) => {
        if (err) throw err;
        res.json(results);
      }
    );
  });

//post/json

//return JSON- sew in postman -working
//http://localhost:5000/json

app.route("/json").post((req, res) => {
  res.json(data);
});


//if we want to bring back the servers and the companies- use join
//do in work bench and then copy to here

app.route("/c").get((req, res) => {
  pool.query(
    "SELECT s.id, s.name ,s.ip ,C.name AS hosting_company, s.status,s.datetime FROM test_3.servers AS S LEFT JOIN test_3.companies AS c ON s.hosting_company=c.id;",
    (err, results) => {
      if (err) throw err;
      res.json(results);
    }
  );
});


//post to get all servers
app.post('/api/server/status',(req,res)=>{
  res.sendStatus(200);
});


//עדכון הסטטוס של השרת

//check if working
app.route("/update").get((req, res) => {
  pool.query(
    "UPDATE test_3.servers SET status = true WHERE id= '1'",
    (err, results) => {
      if (err) throw err;
      res.json(results);
    }
  );
});



//כדי להחזיר את הסטטוסים

app.post('/return/status',(req,res)=>{
  
  pool.query(
    "SELECT status FROM test_3.servers;",
    (err, results) => {
      if (err) throw err;
      res.json(results);
    }
  );
});







app.route("/company/name").get((req, res) => {
  pool.query(
    "SELECT * FROM test_3.companies WHERE id= '1'",
    (err, results) => {
      if (err) throw err;
      res.json(results);
    }
  );
});

const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`server started on port ${port}`));
